# مذاكرتي - مشروع Android WebView

هذا المشروع يغلّف تطبيق الويب الأصلي داخل Android WebView ويحافظ على ملفات التطبيق المحلية.

## استخراج APK عبر GitHub Actions
1. ارفع محتويات هذا المجلد إلى مستودع GitHub جديد (لا ترفع المجلد المضغوط نفسه).
2. افتح تبويب **Actions** في المستودع.
3. اختر **Build Mozakrty APK** ثم **Run workflow**، أو انتظر تشغيله بعد push إلى main/master.
4. بعد نجاح البناء، افتح تشغيل workflow ثم قسم **Artifacts** وحمّل `mozakrty-debug-apk`.
5. فك ضغط Artifact لتحصل على `app-debug.apk`.

## بناء محلي
يتطلب Java 17 و Android SDK و Gradle 8.9+، ثم:
`gradle assembleDebug`

ملحوظة: هذا قالب بناء APK، وليس APK مبني مسبقًا.
