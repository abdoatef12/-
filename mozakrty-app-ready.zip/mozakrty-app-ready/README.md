# مذاكرتي

تطبيق مذاكرة عربي بسيط (PWA).

## النشر على GitHub Pages
1. أنشئ Repository باسم `mozakrty-app`.
2. ارفع محتويات هذا المجلد (لا ترفع ZIP نفسه).
3. Settings → Pages → Deploy from a branch.
4. اختر `main` و`/(root)` ثم Save.
5. انتظر ظهور رابط الموقع في صفحة Pages.
